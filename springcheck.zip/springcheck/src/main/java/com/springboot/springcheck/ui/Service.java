package com.springboot.springcheck.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Service {
	@Autowired
	Repos repo;
	
	public void adddata(SureshDO sure){
		repo.save(sure);
	}
	
	public void redata(){
		System.out.println("ffgt");
		SureshDO ss= (SureshDO) repo.findOne(1);
		System.out.println(ss);
	}
	
	

}
