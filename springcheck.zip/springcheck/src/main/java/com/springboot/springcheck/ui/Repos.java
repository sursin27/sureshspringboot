package com.springboot.springcheck.ui;

import org.springframework.data.repository.CrudRepository;

public interface Repos extends CrudRepository<SureshDO, Integer> {

}
