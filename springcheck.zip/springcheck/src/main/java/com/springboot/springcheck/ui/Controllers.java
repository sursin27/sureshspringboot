package com.springboot.springcheck.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Controllers {

	@Autowired
	Service s;
	@RequestMapping("/post")
	void postmethod(){
		
		SureshDO ss= new SureshDO();
		ss.setId(1);
		ss.setName("sss");
		s.adddata(ss);
		s.redata();
	}
	/*@RequestMapping("/get")
	String getmethod(){
		return "s.redata()";
	}*/

}
